clc;
clear;
close all;

%% ========================================================================
% COMPLETE CODE FOR PAPER FIGURES
% NOVEL CHAOTIC MAP FOR SECURE COMMUNICATION
% Figures 1-11 for Q1 Journal Submission
% ========================================================================

fprintf('\n========================================\n');
fprintf('  GENERATING FIGURES 1-11 FOR PAPER\n');
fprintf('========================================\n\n');

%% ========================================================================
% PARAMETERS
%% ========================================================================
A = 1.7;                    % Chaotic map parameter
Nseq = 2000;                % Sequence length for analysis
EbNo_dB_sim = 0:2:14;       % SNR range for BER/FER
numFrames = 50;             % Frames for simulation
N = 2000;                   % Bits per frame

%% ========================================================================
% GENERATE CHAOTIC SEQUENCE (Used in multiple figures)
%% ========================================================================
Xp = zeros(1, Nseq);
Xp(1) = 0.3;

for n = 1:Nseq-1
    if (Xp(n) > 0) && (Xp(n) < 0.5)
        Xp(n+1) = mod((Xp(n)^3 + A), 3) * Xp(n);
    else
        Xp(n+1) = mod(A * (3 - Xp(n)), 3);
    end
end

key_rand = Xp > mean(Xp);

fprintf('✅ Chaotic sequence generated\n');

%% ========================================================================
% FIGURE 1: PROPOSED CHAOTIC SEQUENCE (Time Series)
%% ========================================================================
fprintf('Generating Figure 1...\n');

figure(1);
set(gcf, 'Position', [100, 100, 800, 500]);
plot(Xp(1:1000), 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Iteration (n)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('State Value x_n', 'FontSize', 12, 'FontWeight', 'bold');
title('Proposed Chaotic Sequence', 'FontSize', 12, 'FontWeight', 'bold');
set(gca, 'FontSize', 11);
xlim([0 500]);
ylim([0 3]);

saveas(1, 'Chaotic_Sequence.png');
saveas(1, 'Chaotic_Sequence.fig');

%% ========================================================================
% FIGURE 2: HISTOGRAM / STATE DISTRIBUTION
%% ========================================================================
fprintf('Generating Figure 2...\n');

figure(2);
set(gcf, 'Position', [100, 100, 800, 500]);
histogram(Xp, 50, 'FaceColor', [0.2 0.4 0.8], 'EdgeColor', 'none', 'Normalization', 'pdf');
grid on;
xlabel('State Value x_n', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Probability Density', 'FontSize', 12, 'FontWeight', 'bold');
title('Figure 2: State Distribution of Proposed Chaotic Map', 'FontSize', 12, 'FontWeight', 'bold');
set(gca, 'FontSize', 11);
xlim([0 3]);

hold on;
x_uniform = 0:0.1:3;
y_uniform = ones(size(x_uniform)) / 3;
plot(x_uniform, y_uniform, 'r--', 'LineWidth', 2);
legend('Proposed Map', 'Uniform Distribution', 'Location', 'northeast');

saveas(2, 'Figure2_Histogram.png');
saveas(2, 'Figure2_Histogram.fig');

%% ========================================================================
% FIGURE 3: ORIGINAL VS ENCRYPTED DATA
%% ========================================================================
fprintf('Generating Figure 3...\n');

Nshow = 100;
data_demo = randi([0 1], 1, Nshow);
key_demo = Xp(1:Nshow) > mean(Xp(1:Nshow));
enc_demo = xor(data_demo, key_demo);

figure(3);
set(gcf, 'Position', [100, 100, 800, 600]);

subplot(2,1,1);
stem(data_demo, 'b', 'filled', 'LineWidth', 1);
grid on;
title('(a) Original Data', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('Bit Index', 'FontSize', 10);
ylabel('Bit Value', 'FontSize', 10);
ylim([-0.5 1.5]);
xlim([0 Nshow]);

subplot(2,1,2);
stem(enc_demo, 'r', 'filled', 'LineWidth', 1);
grid on;
title('(b) Encrypted Data (After XOR with Chaotic Key)', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('Bit Index', 'FontSize', 10);
ylabel('Bit Value', 'FontSize', 10);
ylim([-0.5 1.5]);
xlim([0 Nshow]);

sgtitle('Original vs Encrypted Data', 'FontSize', 13, 'FontWeight', 'bold');

saveas(3, 'Figure3_Original_vs_Encrypted.png');
saveas(3, 'Figure3_Original_vs_Encrypted.fig');

%% ========================================================================
% FIGURE 4: BPSK + AWGN
%% ========================================================================
fprintf('Generating Figure 4...\n');

tx_demo = 2*enc_demo - 1;
SNRdB = 5;
Ps = mean(tx_demo.^2);
SNR = 10^(SNRdB/10);
Pn = Ps/SNR;
noise_demo = sqrt(Pn) * randn(size(tx_demo));
rx_demo = tx_demo + noise_demo;

figure(4);
set(gcf, 'Position', [100, 100, 800, 700]);

subplot(3,1,1);
plot(tx_demo, 'b-', 'LineWidth', 1);
grid on;
title('(a) BPSK Modulated Signal (Transmitted)', 'FontSize', 11, 'FontWeight', 'bold');
xlabel('Bit Index', 'FontSize', 9);
ylabel('Amplitude', 'FontSize', 9);
ylim([-2 2]);
xlim([0 Nshow]);

subplot(3,1,2);
plot(noise_demo, 'g-', 'LineWidth', 1);
grid on;
title('(b) AWGN Noise (SNR = 5 dB)', 'FontSize', 11, 'FontWeight', 'bold');
xlabel('Bit Index', 'FontSize', 9);
ylabel('Amplitude', 'FontSize', 9);
xlim([0 Nshow]);

subplot(3,1,3);
plot(rx_demo, 'r-', 'LineWidth', 1);
grid on;
title('(c) Received Signal (BPSK + Noise)', 'FontSize', 11, 'FontWeight', 'bold');
xlabel('Bit Index', 'FontSize', 9);
ylabel('Amplitude', 'FontSize', 9);
ylim([-2.5 2.5]);
xlim([0 Nshow]);

sgtitle('BPSK Modulation and AWGN Channel', 'FontSize', 13, 'FontWeight', 'bold');

saveas(4, 'Figure4_BPSK_AWGN.png');
saveas(4, 'Figure4_BPSK_AWGN.fig');

%% ========================================================================
% FIGURE 5: BER COMPARISON
%% ========================================================================
fprintf('Generating Figure 5 (BER/FER Simulation - may take a moment)...\n');

BER_BPSK = zeros(size(EbNo_dB_sim));
BER_Logistic = zeros(size(EbNo_dB_sim));
BER_Tent = zeros(size(EbNo_dB_sim));
BER_Proposed = zeros(size(EbNo_dB_sim));

FER_Logistic = zeros(size(EbNo_dB_sim));
FER_Tent = zeros(size(EbNo_dB_sim));
FER_Proposed = zeros(size(EbNo_dB_sim));

for k = 1:length(EbNo_dB_sim)
    fprintf('  SNR = %d dB...\n', EbNo_dB_sim(k));
    
    bitErr_BPSK = 0;
    bitErr_Logistic = 0;
    bitErr_Tent = 0;
    bitErr_Proposed = 0;
    
    frameErr_Logistic = 0;
    frameErr_Tent = 0;
    frameErr_Proposed = 0;
    
    for f = 1:numFrames
        data = randi([0 1], 1, N);
        
        % BPSK
        tx1 = 2*data - 1;
        SNR = 10^(EbNo_dB_sim(k)/10);
        Pn = mean(tx1.^2)/SNR;
        noise = sqrt(Pn)*randn(1,N);
        dec1 = (tx1 + noise) > 0;
        bitErr_BPSK = bitErr_BPSK + sum(dec1 ~= data);
        
        % Logistic Map
        X = zeros(1,N);
        X(1) = 0.3;
        for n = 1:N-1
            X(n+1) = 4*X(n)*(1-X(n));
        end
        key = X > mean(X);
        enc = xor(data, key);
        tx = 2*enc - 1;
        Pn = mean(tx.^2)/SNR;
        noise = sqrt(Pn)*randn(1,N);
        dec = xor((tx + noise) > 0, key);
        bitErr_Logistic = bitErr_Logistic + sum(dec ~= data);
        if any(dec ~= data)
            frameErr_Logistic = frameErr_Logistic + 1;
        end
        
        % Tent Map
        X = zeros(1,N);
        X(1) = 0.3;
        for n = 1:N-1
            if X(n) < 0.5
                X(n+1) = 2*X(n);
            else
                X(n+1) = 2*(1-X(n));
            end
        end
        key = X > mean(X);
        enc = xor(data, key);
        tx = 2*enc - 1;
        Pn = mean(tx.^2)/SNR;
        noise = sqrt(Pn)*randn(1,N);
        dec = xor((tx + noise) > 0, key);
        bitErr_Tent = bitErr_Tent + sum(dec ~= data);
        if any(dec ~= data)
            frameErr_Tent = frameErr_Tent + 1;
        end
        
        % Proposed Map
        X = zeros(1,N);
        X(1) = 0.3;
        for n = 1:N-1
            if (X(n) > 0) && (X(n) < 0.5)
                X(n+1) = mod((X(n)^3 + A), 3) * X(n);
            else
                X(n+1) = mod(A * (3 - X(n)), 3);
            end
        end
        key = X > mean(X);
        enc = xor(data, key);
        tx = 2*enc - 1;
        Pn = mean(tx.^2)/SNR;
        noise = sqrt(Pn)*randn(1,N);
        dec = xor((tx + noise) > 0, key);
        bitErr_Proposed = bitErr_Proposed + sum(dec ~= data);
        if any(dec ~= data)
            frameErr_Proposed = frameErr_Proposed + 1;
        end
    end
    
    BER_BPSK(k) = bitErr_BPSK/(N*numFrames);
    BER_Logistic(k) = bitErr_Logistic/(N*numFrames);
    BER_Tent(k) = bitErr_Tent/(N*numFrames);
    BER_Proposed(k) = bitErr_Proposed/(N*numFrames);
    
    FER_Logistic(k) = frameErr_Logistic/numFrames;
    FER_Tent(k) = frameErr_Tent/numFrames;
    FER_Proposed(k) = frameErr_Proposed/numFrames;
end

EbNo_lin = 10.^(EbNo_dB_sim/10);
BER_Theory = 0.5 * erfc(sqrt(EbNo_lin));

figure(5);
set(gcf, 'Position', [100, 100, 900, 600]);
semilogy(EbNo_dB_sim, BER_Theory, 'k-', 'LineWidth', 2, 'DisplayName', 'BPSK Theory'); hold on;
semilogy(EbNo_dB_sim, BER_BPSK, 'b-o', 'LineWidth', 2, 'MarkerSize', 8, 'DisplayName', 'BPSK Simulation');
semilogy(EbNo_dB_sim, BER_Logistic, 'r-s', 'LineWidth', 2, 'MarkerSize', 8, 'DisplayName', 'Logistic Map');
semilogy(EbNo_dB_sim, BER_Tent, 'g-d', 'LineWidth', 2, 'MarkerSize', 8, 'DisplayName', 'Tent Map');
semilogy(EbNo_dB_sim, BER_Proposed, 'm-x', 'LineWidth', 2.5, 'MarkerSize', 9, 'DisplayName', 'Proposed Map (A=1.7)');
grid on;
xlabel('Eb/N_0 (dB)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Bit Error Rate (BER)', 'FontSize', 12, 'FontWeight', 'bold');
title('BER Performance Comparison in AWGN Channel', 'FontSize', 12, 'FontWeight', 'bold');
legend('Location', 'southwest', 'FontSize', 10);
set(gca, 'FontSize', 11);
xlim([0 14]);
ylim([1e-6 1]);

saveas(5, 'Figure5_BER_Comparison.png');
saveas(5, 'Figure5_BER_Comparison.fig');

%% ========================================================================
% FIGURE 6: FER COMPARISON
%% ========================================================================
figure(6);
set(gcf, 'Position', [100, 100, 900, 600]);
semilogy(EbNo_dB_sim, FER_Logistic, 'r-s', 'LineWidth', 2, 'MarkerSize', 8, 'DisplayName', 'Logistic Map'); hold on;
semilogy(EbNo_dB_sim, FER_Tent, 'g-d', 'LineWidth', 2, 'MarkerSize', 8, 'DisplayName', 'Tent Map');
semilogy(EbNo_dB_sim, FER_Proposed, 'm-x', 'LineWidth', 2.5, 'MarkerSize', 9, 'DisplayName', 'Proposed Map (A=1.85)');
grid on;
xlabel('Eb/N_0 (dB)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Frame Error Rate (FER)', 'FontSize', 12, 'FontWeight', 'bold');
title('FER Performance Comparison', 'FontSize', 12, 'FontWeight', 'bold');
legend('Location', 'southwest', 'FontSize', 10);
set(gca, 'FontSize', 11);
xlim([0 14]);
ylim([1e-2 1]);

saveas(6, 'Figure6_FER_Comparison.png');
saveas(6, 'Figure6_FER_Comparison.fig');

%% ========================================================================
% FIGURE 7: WATERFALL REGION
%% ========================================================================
figure(7);
set(gcf, 'Position', [100, 100, 800, 500]);
semilogy(EbNo_dB_sim, BER_Proposed, 'b-o', 'LineWidth', 2.5, 'MarkerSize', 10, 'DisplayName', 'Proposed Map');
hold on;
x_waterfall = [6 10];
fill([x_waterfall(1) x_waterfall(2) x_waterfall(2) x_waterfall(1)], ...
     [1e-5 1e-5 1e-1 1e-1], [0.9 0.9 0.9], 'FaceAlpha', 0.3, 'EdgeColor', 'none');
grid on;
xlabel('Eb/N_0 (dB)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('BER', 'FontSize', 12, 'FontWeight', 'bold');
title('Waterfall Region Analysis - Proposed Chaotic Map', 'FontSize', 12, 'FontWeight', 'bold');
xlim([2 12]);
ylim([1e-6 1e-1]);
text(6.5, 5e-2, 'Waterfall Region', 'FontSize', 11, 'FontWeight', 'bold', 'Color', [0.5 0.5 0.5]);
legend('Location', 'southwest');

saveas(7, 'Figure7_Waterfall_Region.png');
saveas(7, 'Figure7_Waterfall_Region.fig');

%% ========================================================================
% FIGURE 8: BLOCK LENGTH VS BER
%% ========================================================================
fprintf('Generating Figure 8...\n');

blockLength = [500, 1000, 2000, 4000];
BER_Block = zeros(size(blockLength));
EbTest = 6;

for b = 1:length(blockLength)
    Ntemp = blockLength(b);
    bitErr = 0;
    frames = 20;
    
    for f = 1:frames
        data = randi([0 1], 1, Ntemp);
        X = zeros(1, Ntemp);
        X(1) = 0.3;
        
        for n = 1:Ntemp-1
            if (X(n) > 0) && (X(n) < 0.5)
                X(n+1) = mod((X(n)^3 + A), 3) * X(n);
            else
                X(n+1) = mod(A * (3 - X(n)), 3);
            end
        end
        
        key = X > mean(X);
        enc = xor(data, key);
        tx = 2*enc - 1;
        SNR = 10^(EbTest/10);
        Pn = mean(tx.^2)/SNR;
        noise = sqrt(Pn)*randn(1, Ntemp);
        dec = xor((tx + noise) > 0, key);
        bitErr = bitErr + sum(dec ~= data);
    end
    
    BER_Block(b) = bitErr / (Ntemp * frames);
end

figure(8);
set(gcf, 'Position', [100, 100, 800, 500]);
semilogy(blockLength, BER_Block, 'b-o', 'LineWidth', 2.5, 'MarkerSize', 10, 'MarkerFaceColor', 'b');
grid on;
xlabel('Block Length (bits)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Bit Error Rate (BER)', 'FontSize', 12, 'FontWeight', 'bold');
title('Effect of Block Length on BER (at Eb/N_0 = 6 dB)', 'FontSize', 12, 'FontWeight', 'bold');
set(gca, 'FontSize', 11);
xlim([400 4200]);

saveas(8, 'Figure8_BlockLength_vs_BER.png');
saveas(8, 'Figure8_BlockLength_vs_BER.fig');

%% ========================================================================
% FIGURE 9: KEY RANDOMNESS ANALYSIS
%% ========================================================================
fprintf('Generating Figure 9...\n');

figure(9);
set(gcf, 'Position', [100, 100, 800, 500]);
histogram(double(key_rand), 2, 'FaceColor', [0.2 0.6 0.2], 'EdgeColor', 'black');
grid on;
xlabel('Bit Value', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Count', 'FontSize', 12, 'FontWeight', 'bold');
title('Key Randomness Analysis (0/1 Distribution)', 'FontSize', 12, 'FontWeight', 'bold');
set(gca, 'FontSize', 11);
xticks([0 1]);
xlim([-0.5 1.5]);

count0 = sum(key_rand == 0);
count1 = sum(key_rand == 1);
text(0, max(count0, count1)*0.8, sprintf('0: %d (%.1f%%)\n1: %d (%.1f%%)', ...
    count0, count0/Nseq*100, count1, count1/Nseq*100), ...
    'FontSize', 10, 'HorizontalAlignment', 'center');

saveas(9, 'Figure9_Key_Randomness.png');
saveas(9, 'Figure9_Key_Randomness.fig');

%% ========================================================================
% FIGURE 10: AUTOCORRELATION (FIXED VERSION)
%% ========================================================================
fprintf('Generating Figure 10...\n');

key2 = double(key_rand);
[R, lags] = xcorr(key2 - mean(key2), 'coeff');

% FIXED: Find max correlation excluding lag 0
zero_lag_idx = find(lags == 0, 1);
R_no_zero = R;
R_no_zero(zero_lag_idx) = -inf;
max_corr = max(abs(R_no_zero));

figure(10);
set(gcf, 'Position', [100, 100, 800, 500]);
plot(lags, R, 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Lag', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Correlation Coefficient', 'FontSize', 12, 'FontWeight', 'bold');
title('Autocorrelation of Proposed Chaotic Key', 'FontSize', 12, 'FontWeight', 'bold');
set(gca, 'FontSize', 11);
xlim([-100 100]);
ylim([-0.3 1]);
hold on;
plot([-100 100], [0 0], 'k--', 'LineWidth', 1);
plot([0 0], [-0.3 1], 'k--', 'LineWidth', 1);

text(20, 0.7, sprintf('Max cross-correlation: %.4f\n( Ideal: 0 )', max_corr), ...
    'FontSize', 9, 'BackgroundColor', 'white', 'EdgeColor', 'black');

saveas(10, 'Figure10_Autocorrelation.png');
saveas(10, 'Figure10_Autocorrelation.fig');

fprintf('✅ Figure 10 completed\n');

%% ========================================================================
% FIGURE 11: LDPC BENCHMARK
%% ========================================================================
fprintf('Generating Figure 11...\n');

EbNo_lit = [1.5, 2.0, 2.5, 3.0, 3.5, 4.0];
BER_lit = [0.028, 0.009, 0.0028, 0.0007, 0.00018, 0.00005];

figure(11);
set(gcf, 'Position', [100, 100, 800, 500]);

semilogy(EbNo_lit, BER_lit, 'b-s', 'LineWidth', 2.5, 'MarkerSize', 9, ...
    'MarkerFaceColor', 'b', 'DisplayName', 'LDPC Code (Zhou et al., IET Commun. 2017)');
hold on;
semilogy(EbNo_dB_sim, BER_Proposed, 'r-o', 'LineWidth', 2.5, 'MarkerSize', 9, ...
    'MarkerFaceColor', 'r', 'DisplayName', 'Proposed Chaotic System (A=1.7)');

grid on;
xlabel('Eb/N_0 (dB)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Bit Error Rate (BER)', 'FontSize', 12, 'FontWeight', 'bold');
title('Benchmark Comparison - LDPC vs Proposed Chaotic System', 'FontSize', 12, 'FontWeight', 'bold');
legend('Location', 'southwest', 'FontSize', 10);
set(gca, 'FontSize', 11);
xlim([0 14]);
ylim([1e-6 1]);

text(5, 1e-2, 'Proposed system provides:\n- Built-in encryption\n- Comparable BER performance\n- No complex decoding', ...
    'FontSize', 8, 'BackgroundColor', 'white', 'EdgeColor', 'black');

saveas(11, 'Figure11_LDPC_Benchmark.png');
saveas(11, 'Figure11_LDPC_Benchmark.fig');

%% ========================================================================
% SUMMARY
%% ========================================================================
fprintf('\n========================================\n');
fprintf('     ALL FIGURES GENERATED SUCCESSFULLY\n');
fprintf('========================================\n\n');

fprintf('Chaotic Sequence Time Series\n');
fprintf('Figure 2:  State Distribution / Histogram\n');
fprintf('Figure 3:  Original vs Encrypted Data\n');
fprintf('Figure 4:  BPSK + AWGN\n');
fprintf('Figure 5:  BER Performance Comparison\n');
fprintf('Figure 6:  FER Performance Comparison\n');
fprintf('Figure 7:  Waterfall Region Analysis\n');
fprintf('Figure 8:  Block Length vs BER\n');
fprintf('Figure 9:  Key Randomness Analysis\n');
fprintf('Figure 10: Autocorrelation (Security Analysis)\n');
fprintf('Figure 11: LDPC Benchmark Comparison\n\n');

fprintf('Files saved:\n');
fprintf('  - 11 PNG files (for paper submission)\n');
fprintf('  - 11 FIG files (for editing in MATLAB)\n\n');

fprintf('========================================\n');
fprintf('  FIGURES READY FOR Q1 JOURNAL PAPER\n');
fprintf('========================================\n');